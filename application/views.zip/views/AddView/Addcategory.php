<?php include_once('header.php');
include_once('sidebar.php'); ?>

<br><br><br><br>

<div class="container">
    <div class="breadcrumb-header justify-content-between">
        <div class="my-auto">
            <div class="d-flex">
                <h4 class="content-title mb-0 my-auto">Add Category</h4>
            </div>
        </div>
    </div>
    <br><br>
    <div class="card">
        <div class="card-body">
            <div class="AddStoreDiv">
                <form class="AddStoreForm" action="<?= base_url('Additems/Addcategory') ?>" method="post"  enctype="multipart/form-data">

                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Category name</label>
                        <select class="form-control" id="exampleFormControlSelect1" name="Categoryname">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Brands</label>
                        <select class="form-control" id="exampleFormControlSelect1" name="brands">
                            <option>abc</option>
                            <option>efgh</option>
                            <option>ijk</option>
                            <option>lmno</option>
                            <option>kblo</option>
                        </select>
                    </div>
                        <div class="form-group">
                        <label for="exampleFormControlSelect1">Image</label>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="customFile" name="image">
                            <label class="custom-file-label" for="customFile">Choose file</label>
                        </div>
             </div>
             <button type="submit" class="btn btn-primary">Add</button>
            </form>
            </div>
        </div>
    </div>

    <?php include_once('footer.php'); ?>